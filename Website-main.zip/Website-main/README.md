# The Official website of Minimax Studio 
The All-in-one Digital Design Agency in Sri Lanka.

 <h4>The Art Makes You Feel Something;
 The Design Makes You Do Something</h4>
 

 
